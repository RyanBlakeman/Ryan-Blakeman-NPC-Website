CREATE TABLE doctors (
         doctor_id     INT (4) NOT NULL,
         doc_name      VARCHAR(30) NOT NULL,
         telephone_no  VARCHAR(12) NOT NULL,
	 office_no     INT NOT NULL,
         email         VARCHAR(30) NOT NULL UNIQUE,
         type_of_work  CHAR CHECK (type_of_work IN ('F','f','P','p')) 
         
);

CREATE TABLE nurse (
         nurse_id       INT (2) NOT NULL,
         nurse_name     VARCHAR(30) NOT NULL,
         office_no      VARCHAR(2) NOT NULL,
         email          VARCHAR(30) NOT NULL UNIQUE,
         type_of_work   CHAR CHECK (type_of_work IN ('F','f','P','p'))
         
);

CREATE TABLE available_appointments (
		appointment_id   INT (2) NOT NULL,
		appointment_date VARCHAR(10) NOT NULL
);

CREATE TABLE current_pets (
		pet_id   INT (4) NOT NULL,
		pet_name VARCHAR(30) NOT NULL,
		pet_type VARCHAR(30) NOT NULL,
		pet_breed VARCHAR(30) NOT NULL,
		pet_gender CHAR(1) NOT NULL,
		pet_description VARCHAR(80) NOT NULL
);

CREATE TABLE services (
		service_id  INT (4) NOT NULL,
		service_name VARCHAR(30) NOT NULL,
		service_price VARCHAR(5) NOT NULL
);

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2200', 'Dr Cleverly Edwards', '07907887172', '12', 'Cleverly_cl@noahs.com', 'P');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2201', 'Dr Mike Phillips', '07187463827', '34', 'MikeK@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2202', 'Dr Farraday Holland', '07183009567', '34', 'FarradayF@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2203', 'Dr Fred Batson', '07476648374', '41', 'FredF@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2204', 'Dr Watson Carr', '07583421568', '1', 'WatsS@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2205', 'Dr Freeman Campbell', '07732039421', '2', 'FreemanF@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2206', 'Dr Crowley Dunn', '07234963498', '10', 'CrowleyC@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2207', 'Dr Rahib Burke', '07854938412', '16', 'RahibB@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2208', 'Dr Susana Willson', '07932254935', '13', 'Susanawillson@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2209', 'Dr Aleem Rizak', '01612991847', '24', 'Aleemrizak@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2210', 'Dr Jeremy Luxenburg', '01611585674', '17', 'Jeremylux@noahs.com', 'P');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2211', 'Dr Sharon Hallow', '07955842932', '19', 'Sharonhallow@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2212', 'Dr Jack Gidley', '07582754296 ', '28', 'Jackgidley456@noahs.com', 'P');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2213', 'Dr Shannon Ball', '07943857463', '29', 'ShannonB34@noahs.com', 'P');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2214', 'Dr Ethan Francis', '07075463521', '13', 'EthanF90@noahs.com', 'F');

INSERT INTO doctors (doctor_id, doc_name, telephone_no, office_no, email, type_of_work)
VALUES ('2215', 'Dr Kian Ashton', '07092435498', '11', 'KianAshton123321@noahs.com', 'P');



INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('1', 'Mary Tills', '00', 'MaryTills12@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('2', 'Jennifer Wood', '00', 'JenniferW1@noahs.com', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('3', 'Aida Richardson', '00', 'AidaRichardson@noahs.com', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('4', 'Paige Clark', '00', 'PaigeClark87@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('5', 'Liam Adams', '00', 'LiamAdamms@noahs.com', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('6', 'Olivia Elliott', '00', 'OliviaElliot1@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('7', 'Rebecca Howells', '00', 'RebeccaHowells123@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('8', 'Hannah Carroll', '00', 'HannahCarroll99@noahs.com', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('9', 'Paul Wety', '00', 'PaulWety10@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('10', 'Robert Williams', '00', 'RobertW@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('11', 'Ted Warner', '00', 'TedW145@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('12', 'Kellan Monty', '00', 'KellanM@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('13', 'Alexia Johnston', '00', 'AlexiaJohnston66@noahs.com', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('14', 'Evelyn Gibson', '00', 'EvelynGibson121@noahs.com', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('15', 'Mike Spencer', '00', 'MikeSpencer87@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('16', 'Alex Foster', '00', 'AlexFoster876@noahs.com ', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('17', 'Jasmine Cooke', '00', 'JasmineCooke999@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('18', 'Lewis James', '00', 'LewisJames121@noahs.com', 'P');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('19', 'Zara Elliot', '00', 'ZaraElliot888@noahs.com', 'F');

INSERT INTO nurse (nurse_id, nurse_name, office_no, email, type_of_work)
VALUES ('20', 'Finlay Baldwin', '00', 'FinlayBaldwin66@noahs.com', 'F');



INSERT INTO available_appointments (appointment_id, appointment_date)
VALUES ('1','26/10/2020');

INSERT INTO available_appointments (appointment_id, appointment_date)
VALUES ('2','30/10/2020');

INSERT INTO available_appointments (appointment_id, appointment_date)
VALUES ('3','2/11/2020');

INSERT INTO available_appointments (appointment_id, appointment_date)
VALUES ('4','6/11/2020');

INSERT INTO available_appointments (appointment_id, appointment_date)
VALUES ('5','9/11/2020');



INSERT INTO current_pets (pet_id, pet_name, pet_type, pet_breed, pet_gender, pet_description)
VALUES ('1020', 'Elbert', 'Dog', 'Labrador', 'M', 'He needed surgery for a sprained leg');

INSERT INTO current_pets (pet_id, pet_name, pet_type, pet_breed, pet_gender, pet_description)
VALUES ('1021', 'Daisy', 'Dog', 'Alsation', 'F', 'She needed a check-up');

INSERT INTO current_pets (pet_id, pet_name, pet_type, pet_breed, pet_gender, pet_description)
VALUES ('1022', 'Bell', 'Cat', 'Persian', 'F', 'She needed microchipping');

INSERT INTO current_pets (pet_id, pet_name, pet_type, pet_breed, pet_gender, pet_description)
VALUES ('1023', 'Woody', 'Rabbit', 'American', 'M', 'He needed microchipping');

INSERT INTO current_pets (pet_id, pet_name, pet_type, pet_breed, pet_gender, pet_description)
VALUES ('1024', 'Buzz', 'Dog', 'Terrier', 'M', 'He needed neutering');

INSERT INTO current_pets (pet_id, pet_name, pet_type, pet_breed, pet_gender, pet_description)
VALUES ('1025', 'Chippy', 'Bird', 'Budgie', 'M', 'He needed pet insurance');



INSERT INTO services (service_id, service_name, service_price)
VALUES ('1', 'Dog Vaccination', '60');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('2', 'Cat Vaccination', '55');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('3', 'Rabbit Vaccination', '50');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('4', 'Consultation', '30');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('5', 'Surgery', '80');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('6', 'Emergency', '95');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('7', 'Microchipping', '20');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('8', 'Neutering', '100');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('9', 'Pet Insurance', '150');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('10', 'Referral', '140');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('11', 'Repeat Perscription', '25');

INSERT INTO services (service_id, service_name, service_price)
VALUES ('12', 'Check-up', '55');