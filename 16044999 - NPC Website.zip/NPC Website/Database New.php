<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Noah's Pet Clinic</title>
<link href="css/NPCindex.css" rel="stylesheet" type="text/css">
<style type="text/css">
table, th, td {
    border: 1px solid black;
}
.container header #menu ul li strong {
	font-family: Cambria, Hoefler Text, Liberation Serif, Times, Times New Roman, serif;
}
.container header #menu ul li strong {
	font-family: Gotham, Helvetica Neue, Helvetica, Arial, sans-serif;
}
.k {
	font-family: Gotham, Helvetica Neue, Helvetica, Arial, sans-serif;
}
</style>
<script type="text/javascript">
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
</head>
<body  background="Pictures/Back Ground.jpg" onLoad="MM_preloadImages('Pictures/Home Page Pictures/Socials/PhoneNumber .png','Pictures/Home Page Pictures/Socials/EmailAddress.png','Pictures/Home Page Pictures/Socials/FacebookPage.png','Pictures/Home Page Pictures/Socials/TwitterPage.png','Pictures/Home Page Pictures/Buttons/Home Text Black.png','Pictures/Home Page Pictures/Buttons/Products Text Black.png','Pictures/Home Page Pictures/Buttons/Photos Text Black.png','Pictures/Home Page Pictures/Buttons/Contact Text Black.png','Pictures/Home Page Pictures/Buttons/About Us Text Black.png','Pictures/Home Page Pictures/Buttons/Database Text Black.png','Pictures/Products and Services Pictures/Products Roll Over/Dog fd.png','Pictures/Products and Services Pictures/Products Roll Over/Cat ing.png','Pictures/Products and Services Pictures/Products Roll Over/Rabbit Info.png','Pictures/Products and Services Pictures/Products Roll Over/FrontLine Info.png','Pictures/Products and Services Pictures/Products Roll Over/Cat Info.png','Pictures/Products and Services Pictures/Products Roll Over/Bedding Info.png','Pictures/Products and Services Pictures/Products Roll Over/Chuck it info.png','Pictures/Products and Services Pictures/Products Roll Over/Cat Toy Info.png')">
	<div class="primary_header">
      <div><img src="Pictures/Logo.png" width="1000" height="111" alt=""/></div>
      <h1 class="title"></h1>
</div>
<div class="container">
  <header>
    <nav class="secondary_header" id="menu">
      <ul>
        <li><a href="Homepage.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Home ','','Pictures/Home Page Pictures/Buttons/Home Text Black.png',1)"><img src="Pictures/Home Page Pictures/Buttons/Home Text White.png" alt="" width="65" height="25" id="RollOver Home "></a></li>
        <li><a href="Products and Services New.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Products','','Pictures/Home Page Pictures/Buttons/Products Text Black.png',1)"><img src="Pictures/Home Page Pictures/Buttons/Products Text White.png" alt="" width="123" height="52" id="RollOver Products"></a></li>
        <li><a href="Database New.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Database','','Pictures/Home Page Pictures/Buttons/Database Text Black.png',1)"><img src="Pictures/Home Page Pictures/Buttons/Database Text White.png" alt="" width="100" height="25" id="RollOver Database"></a></li>
        <li><a href="Photos.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Photos','','Pictures/Home Page Pictures/Buttons/Photos Text Black.png',1)"><img src="Pictures/Home Page Pictures/Buttons/Photos Text White.png" alt="" width="90" height="25" id="RollOver Photos"></a></li>
        <li><a href="Contact.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Contact','','Pictures/Home Page Pictures/Buttons/Contact Text Black.png',1)"><img src="Pictures/Home Page Pictures/Buttons/Contact Text White.png" alt="" width="90" height="25" id="RollOver Contact"></a></li>
        <li><a href="About Us.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver About Us','','Pictures/Home Page Pictures/Buttons/About Us Text Black.png',1)"><img src="Pictures/Home Page Pictures/Buttons/About Us Text White.png" alt="" width="110" height="25" id="RollOver About Us"></a></li>
        <p>&nbsp;</p>
      </ul>
    </nav>
  </header>
  <section>
    <h2 class="noDisplay">Main Content</h2>
	  <div class="left_article_products">
	    <h3 class="k"><u>Database</u></h3>
<h5>
  <p>To view contact details of our specialist vet doctors and nurses, please use the selection box below. As well as the next available appointments, to book one of these appointments click <a href="Contact.html">here</a>. The selection box also shows some of the current pets that are currently registered to the clinic and have been recently treated by our incredible vet doctors and nurses. </p>
	      
		  </h5>
    <div class="column_half left_half_t"><form action="Database New.php" method="post" class="lead" id="serviceForm">
	<h2 class="lead" id="services"><strong><em> Please select a Table to view records from the NPC Database</em></strong></h2>
<select name="select" class="lead" id="service">
	  <option value="Select a Table...">Select a Table...</option>
		<option value="1">Doctors</option>
		<option value="2">Nurses</option>
		<option value="3">Current Pets</option>
		<option value="4">Available Appointments</option>
	  </select>
		<input type="submit" class="submit" value="Submit">
	</form>
	
<?php
	if (isset($_POST['select']))
	{
	$selection = $_POST['select'];

		$con = mysqli_connect("localhost", "root", "", "npc");
		if (!$con)
		{
			die ("Connection to Database Failed");
		}
		
		else 
		{	
		 $sql = "SELECT * FROM doctors WHERE 1 = '$selection' ORDER BY doctor_id ASC";
		 
		}
		
		$result = $con -> query($sql);
		
        if ($result->num_rows > 0) {
 echo "<table><tr><th>Doctor ID</th><th>Doctor Name</th><th>Telephone Number</th><th>Office Number</th><th>Email</th><th>Employment</th></tr>";

            while($row = $result->fetch_assoc()) {
               
echo "<tr><td>".$row["doctor_id"]. "</td><td>"  .$row["doc_name"]. "</td><td>" .$row["telephone_no"]."</td><td>" .$row["office_no"]."</td><td>".$row["email"]."</td><td>".$row["type_of_work"];
}
}		
}
	?>
	</td>
	</tr>		 
	</table>

<?php
	if (isset($_POST['select']))
	{
	$selection = $_POST['select'];

		$con = mysqli_connect("localhost", "root", "", "npc");
		if (!$con)
		{
			die ("Connection to Database Failed");
		}
		
		else 
		{	
		 $sql = "SELECT * FROM nurse WHERE 2 = '$selection' ORDER BY nurse_id ASC";
		 
		}
		
		$result = $con -> query($sql);
		
        if ($result->num_rows > 0) {
 echo "<table><tr><th>Nurse ID</th><th>Nurse Name</th><th>Office Number</th><th>Email</th><th>Employment</th></tr>";

            while($row = $result->fetch_assoc()) {
            
echo "<tr><td>".$row["nurse_id"]. "</td><td>"  .$row["nurse_name"]. "</td><td>".$row["office_no"]."</td><td>".$row["email"]."</td><td>".$row["type_of_work"]   ;
          
}
}	
}
	?>
	</td>
	</tr>
	</table>

<?php
	if (isset($_POST['select']))
	{
	$selection = $_POST['select'];

		$con = mysqli_connect("localhost", "root", "", "npc");
		if (!$con)
		{
			die ("Connection to Database Failed");
		}
		
		else 
		{	
		 $sql = "SELECT * FROM current_pets WHERE 3 = '$selection' ORDER BY pet_id ASC";
		 
		}
		
		$result = $con -> query($sql);
		
        if ($result->num_rows > 0) {
 echo "<table><tr><th>Pet ID</th><th>Pet Name</th><th>Pet Type</th><th>Pet Breed</th><th>Pet Gender</th><th>Pet Description</th></tr>";

            while($row = $result->fetch_assoc()) {
               
echo "<tr><td>".$row["pet_id"]. "</td><td>"  .$row["pet_name"]. "</td><td>" .$row["pet_type"]."</td><td>" .$row["pet_breed"]."</td><td>".$row["pet_gender"]."</td><td>".$row["pet_description"];
}
}		
}
	?>
	</td>
	</tr>
	</table>

<?php
	if (isset($_POST['select']))
	{
	$selection = $_POST['select'];

		$con = mysqli_connect("localhost", "root", "", "npc");
		if (!$con)
		{
			die ("Connection to Database Failed");
		}
		
		else 
		{	
		 $sql = "SELECT * FROM available_appointments WHERE 4 = '$selection' ORDER BY appointment_id ASC";
		 
		}
		
		$result = $con -> query($sql);
		
        if ($result->num_rows > 0) {
 echo "<table><tr><th>Appointment ID</th><th>Appointment Date</th></tr>";

            while($row = $result->fetch_assoc()) {
               
echo "<tr><td>".$row["appointment_id"]. "</td><td>"  .$row["appointment_date"];
}
}		
}
	?>
	</td>
	</tr>
	</table>
</div>

	<div class="social">
    <p class="social_icon"><a href="Contact.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Phone','','Pictures/Home Page Pictures/Socials/PhoneNumber .png',1)"><img src="Pictures/Home Page Pictures/Socials/Phone.png" alt="" width="100" height="100" id="RollOver Phone"></a></p>
    <p class="social_icon"><a href="Contact.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Email','','Pictures/Home Page Pictures/Socials/EmailAddress.png',1)"><img src="Pictures/Home Page Pictures/Socials/Email.png" alt="" width="100" height="100" id="RollOver Email"></a></p>
    <p class="social_icon"><a href="Contact.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Facebook','','Pictures/Home Page Pictures/Socials/FacebookPage.png',1)"><img src="Pictures/Home Page Pictures/Socials/Facebook.png" alt="" width="100" height="100" id="RollOver Facebook"></a></p>
    <p class="social_icon"><a href="Contact.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('RollOver Twitter','','Pictures/Home Page Pictures/Socials/TwitterPage.png',1)"><img src="Pictures/Home Page Pictures/Socials/Twitter.png" alt="" width="100" height="100" id="RollOver Twitter"></a></p>
  </div>
  <footer class="secondary_header footer">
    <div class="copyright">Copyright&copy;2020 -Noahs Pet Clinic. All Rights Reserved</div>
  </footer>

</body>
</html>